package com.example.todolist;

import android.content.DialogInterface;

public interface OnDialogCloseListner {
    void onDialogClose(DialogInterface dialogInterface);
}
